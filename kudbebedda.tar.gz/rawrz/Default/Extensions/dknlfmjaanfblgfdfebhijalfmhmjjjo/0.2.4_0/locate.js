(async()=>{var t,e;t=self,e=()=>(()=>{"use strict";var r,d,t,i={d:(t,e)=>{for(var n in e)i.o(e,n)&&!i.o(t,n)&&Object.defineProperty(t,n,{enumerable:!0,get:e[n]})},o:(t,e)=>Object.prototype.hasOwnProperty.call(t,e),r:t=>{"undefined"!=typeof Symbol&&Symbol.toStringTag&&Object.defineProperty(t,Symbol.toStringTag,{value:"Module"}),Object.defineProperty(t,"__esModule",{value:!0})}},e={};function c(t){return t&&t instanceof Element}i.r(e),i.d(e,{default:()=>W,getCssSelector:()=>L}),(t=r=r||{}).NONE="none",t.DESCENDANT="descendant",t.CHILD="child",(t=d=d||{}).id="id",t.class="class",t.tag="tag",t.attribute="attribute",t.nthchild="nthchild",t.nthoftype="nthoftype";const h={selectors:[d.id,d.class,d.tag,d.attribute],includeTag:!1,whitelist:[],blacklist:[],combineWithinSelector:!0,combineBetweenSelectors:!0,root:null,maxCombinations:Number.POSITIVE_INFINITY,maxCandidates:Number.POSITIVE_INFINITY};function o(t){return t instanceof RegExp}function n(t){return["string","function"].includes(typeof t)||o(t)}function u(t){return Array.isArray(t)?t.filter(n):[]}function s(t){var e=[Node.DOCUMENT_NODE,Node.DOCUMENT_FRAGMENT_NODE,Node.ELEMENT_NODE];return t instanceof Node&&e.includes(t.nodeType)}function p(t,e){return s(t)?(t.contains(e),t):s(t=e.getRootNode({composed:!1}))?(document,t):e.ownerDocument.querySelector(":root")}function f(t){return"number"==typeof t?t:Number.POSITIVE_INFINITY}function m(t=[]){var[t=[],...e]=t;return 0===e.length?t:e.reduce((t,e)=>t.filter(t=>e.includes(t)),t)}function g(t){return[].concat(...t)}function E(t){const n=t.map(e=>{if(o(e))return t=>e.test(t);if("function"==typeof e)return t=>{t=e(t);return"boolean"==typeof t&&t};if("string"!=typeof e)return()=>!1;{const n=new RegExp("^"+e.replace(/[|\\{}()[\]^$+?.]/g,"\\$&").replace(/\*/g,".+")+"$");return t=>n.test(t)}});return e=>n.some(t=>t(e))}function b(t,e,n){const i=Array.from(p(n,t[0]).querySelectorAll(e));return i.length===t.length&&t.every(t=>i.includes(t))}function A(t,e){e=null!=e?e:t.ownerDocument.querySelector(":root");var n=[];let i=t;for(;c(i)&&i!==e;)n.push(i),i=i.parentElement;return n}const a={[r.NONE]:{type:r.NONE,value:""},[r.DESCENDANT]:{type:r.DESCENDANT,value:" > "},[r.CHILD]:{type:r.CHILD,value:" "}},l=new RegExp(["^$","\\s"].join("|")),_=new RegExp(["^$"].join("|")),$=[d.nthoftype,d.tag,d.id,d.class,d.attribute,d.nthchild],N=E(["class","id","ng-*"]);function S({nodeName:t}){return`[${t}]`}function y({nodeName:t,nodeValue:e}){return`[${t}='${k(e)}']`}function x(n){var t=Array.from(n.attributes).filter(t=>{var[t,e]=[t.nodeName,n];return e=e.tagName.toLowerCase(),!(["input","option"].includes(e)&&"value"===t||N(t))});return[...t.map(S),...t.map(y)]}function v(t){return(t.getAttribute("class")||"").trim().split(/\s+/).filter(t=>!_.test(t)).map(t=>"."+k(t))}function C(t){var e=t.getAttribute("id")||"",n="#"+k(e),i=t.getRootNode({composed:!1});return!l.test(e)&&b([t],n,i)?[n]:[]}function w(t){var e=t.parentNode;if(e){e=Array.from(e.childNodes).filter(c).indexOf(t);if(-1<e)return[`:nth-child(${e+1})`]}return[]}function M(t){return[k(t.tagName.toLowerCase())]}function P(t){t=[...new Set(g(t.map(M)))];return 0===t.length||1<t.length?[]:[t[0]]}function O(t){const e=P([t])[0],n=t.parentElement;if(n){t=Array.from(n.children).filter(t=>t.tagName.toLowerCase()===e).indexOf(t);if(-1<t)return[e+`:nth-of-type(${t+1})`]}return[]}function I(e=[],{maxResults:t=Number.POSITIVE_INFINITY}={}){var n=[];let i=0,r=T(1);for(;r.length<=e.length&&i<t;)i+=1,n.push(r.map(t=>e[t])),r=function(t=[],e){var n=t.length;if(0===n)return[];var i=[...t];i[n-1]+=1;for(let t=n-1;0<=t;t--)if(i[t]>e){if(0===t)return T(n+1);i[t-1]++,i[t]=i[t-1]+1}return e<i[n-1]?T(n+1):i}(r,e.length-1);return n}function T(t=1){return Array.from(Array(t).keys())}const D=":".charCodeAt(0).toString(16).toUpperCase(),R=/[ !"#$%&'()\[\]{|}<>*+,./;=?@^`~\\]/;function k(t=""){var e;return null!=(e=null==(e=null===CSS||void 0===CSS?void 0:CSS.escape)?void 0:e.call(CSS,t))?e:([e=""]=[t],e.split("").map(t=>":"===t?`\\${D} `:R.test(t)?"\\"+t:escape(t).replace(/%/g,"\\")).join(""))}const j={tag:P,id:function(t){return 0===t.length||1<t.length?[]:C(t[0])},class:function(t){return m(t.map(v))},attribute:function(t){return m(t.map(x))},nthchild:function(t){return m(t.map(w))},nthoftype:function(t){return m(t.map(O))}},H={tag:M,id:C,class:v,attribute:x,nthchild:w,nthoftype:O};function B(t){return t.includes(d.tag)||t.includes(d.nthoftype)?[...t]:[...t,d.tag]}function F(e={}){var t=[...$];return e[d.tag]&&e[d.nthoftype]&&t.splice(t.indexOf(d.tag),1),t.map(t=>{return e[t=t]?e[t].join(""):""}).join("")}function J(t,e,n="",i){var r,o,s,a,l;i.root,s=function(a,n){const{blacklist:t,whitelist:e,combineWithinSelector:l,maxCombinations:d}=n,c=E(t),h=E(e);return function(){var{selectors:t,includeTag:e}=n,t=[].concat(t);return e&&!t.includes("tag")&&t.push("tag"),t}().reduce((t,e)=>{o=a,s=e;var n,i,r,o,s=(null!=(s=j[s])?s:()=>[])(o),s=([o=[],i,r]=[s,c,h],o.filter(t=>r(t)||!i(t))),s=([o=[],n]=[s,h],o.sort((t,e)=>{t=n(t),e=n(e);return t&&!e?-1:!t&&e?1:0}));return t[e]=l?I(s,{maxResults:d}):s.map(t=>[t]),t},{})}(t,o=i),a=s,l=o,s=g(function(){var{selectors:t,combineBetweenSelectors:e,includeTag:n,maxCandidates:i}=l,e=e?I(t,{maxResults:i}):t.map(t=>[t]);return n?e.map(B):e}().map(t=>{{var n=a;const i={};return t.forEach(t=>{var e=n[t];0<e.length&&(i[t]=e)}),function(t={}){let i=[];return Object.entries(t).forEach(([n,t])=>{i=t.flatMap(e=>0===i.length?[{[n]:e}]:i.map(t=>Object.assign(Object.assign({},t),{[n]:e})))}),i}(i).map(F)}}).filter(t=>0<t.length)),o=[...new Set(s)];for(const e of""===n?o:(r=n,[...(o=o).map(t=>r+" "+t),...o.map(t=>r+" > "+t)]))if(b(t,e,i.root))return e;return null}function U(t){return{value:t,include:!1}}function z({selectors:e,operator:t}){let n=[...$],i=(e[d.tag]&&e[d.nthoftype]&&(n=n.filter(t=>t!==d.tag)),"");return n.forEach(t=>{(e[t]||[]).forEach(({value:t,include:e})=>{e&&(i+=t)})}),t.value+i}function V(t){return[":root",...A(t).reverse().map(t=>{t=function(n,t,e=r.NONE){const i={};return t.forEach(t=>{var e;Reflect.set(i,t,(e=n,t=t,H[t](e).map(U)))}),{element:n,operator:a[e],selectors:i}}(t,[d.nthchild],r.DESCENDANT);return t.selectors.nthchild.forEach(t=>{t.include=!0}),t}).map(z)].join("")}function L(t,e={}){const o=function(t){t=(Array.isArray(t)?t:[t]).filter(c);return[...new Set(t)]}(t),s=([t,e={}]=[o[0],e],e=Object.assign(Object.assign({},h),e),{selectors:(n=e.selectors,Array.isArray(n)?n.filter(t=>{return e=d,t=t,Object.values(e).includes(t);var e}):[]),whitelist:u(e.whitelist),blacklist:u(e.blacklist),root:p(e.root,t),combineWithinSelector:!!e.combineWithinSelector,combineBetweenSelectors:!!e.combineBetweenSelectors,includeTag:!!e.includeTag,maxCombinations:f(e.maxCombinations),maxCandidates:f(e.maxCandidates)});var n;let a="",l=s.root;function i(){var[t,e,n="",i]=[o,l,a,s];if(0!==t.length){var r,e=[1<t.length?t:[],...(r=e,m(t.map(t=>A(t,r))).map(t=>[t]))];for(const t of e){const e=J(t,0,n,i);if(e)return{foundElements:t,selector:e}}}return null}let r=i();for(;r;){const{foundElements:t,selector:d}=r;if(b(o,d,s.root))return d;l=t[0],a=d,r=i()}return(1<o.length?o.map(t=>L(t,s)):o.map(V)).join(", ")}const W=L;return e})(),"object"==typeof exports&&"object"==typeof module?module.exports=e():"function"==typeof define&&define.amd?define([],e):"object"==typeof exports?exports.CssSelectorGenerator=e():t.CssSelectorGenerator=e();class i{constructor(t){this.NAMESPACE="__NOPECHA__",this.MARK_RADIUS=5,this.locate=t,this.update_timer,this.initialize_style(),this.initialize_elements()}initialize_style(){var t=[`#${this.NAMESPACE}_wrapper {
                    position: fixed;
                    top: 0;
                    bottom: 0;
                    left: 0;
                    right: 0;
                    background-color: transparent;
                    pointer-events: none;
                    z-index: 10000000;
                }`,`.${this.NAMESPACE}_shadow {
                    position: fixed;
                    top: 0;
                    bottom: 0;
                    left: 0;
                    right: 0;
                    background-color: rgba(0, 0, 0, 0.1);
                    pointer-events: none;
                    z-index: 1;
                }`,`.${this.NAMESPACE}_textbox {
                    display: flex;
                    flex-direction: row;
                    flex-wrap: wrap;

                    position: absolute;
                    left: 0;
                    right: 0;

                    background-color: rgba(0, 0, 0, 1);
                    color: #fff;
                    font: normal 12px/12px Helvetica, sans-serif;
                    text-shadow: 0 1px 1px rgba(0, 0, 0, 0.3);
                    border: 1px solid #fff;
                    overflow: hidden;
                }`,`.${this.NAMESPACE}_textbox.${this.NAMESPACE}_header {
                    top: 0;
                }`,`.${this.NAMESPACE}_textbox.${this.NAMESPACE}_header > div {
                    padding: 4px 8px;
                }`,`.${this.NAMESPACE}_textbox.${this.NAMESPACE}_header > div:first-child {
                    flex-grow: 1;
                }`,`.${this.NAMESPACE}_textbox.${this.NAMESPACE}_footer {
                    bottom: 0;
                }`,`.${this.NAMESPACE}_textbox.${this.NAMESPACE}_footer > div {
                    padding: 4px 8px;
                }`,`.${this.NAMESPACE}_textbox.${this.NAMESPACE}_footer > div:first-child {
                    flex-grow: 1;
                }`,`.${this.NAMESPACE}_highlight {
                    position: absolute;
                    opacity: 0.4;
                }`,`.${this.NAMESPACE}_highlight.${this.NAMESPACE}_margin {
                    background-color: rgb(230, 165, 18);
                }`,`.${this.NAMESPACE}_highlight.${this.NAMESPACE}_border {
                    background-color: rgb(255, 204, 121);
                }`,`.${this.NAMESPACE}_highlight.${this.NAMESPACE}_padding {
                    background-color: rgb(50, 255, 50);
                }`,`.${this.NAMESPACE}_highlight.${this.NAMESPACE}_content {
                    background-color: rgb(0, 153, 201);
                }`,`.${this.NAMESPACE}_mark {
                    position: absolute;
                    top: 0;
                    left: 0;
                    right: 0;

                    width: ${parseInt(2*this.MARK_RADIUS)}px;
                    height: ${parseInt(2*this.MARK_RADIUS)}px;
                    background-color: #f44;
                    border-radius: 50%;
                    z-index: 2;
                }`].join("\n");this.$style=document.createElement("style"),this.$style.type="text/css",this.$style.styleSheet?this.$style.styleSheet.cssText=t:this.$style.innerHTML=t,document.getElementsByTagName("head")[0].appendChild(this.$style)}initialize_elements(){this.$wrapper=document.createElement("div"),this.$wrapper.id=this.NAMESPACE+"_wrapper",document.body.append(this.$wrapper),this.$shadow=document.createElement("div"),this.$shadow.classList.add(this.NAMESPACE+"_shadow"),this.$wrapper.append(this.$shadow),this.$margin_box=document.createElement("div"),this.$margin_box.classList.add(this.NAMESPACE+"_highlight",this.NAMESPACE+"_margin"),this.$wrapper.append(this.$margin_box),this.$border_box=document.createElement("div"),this.$border_box.classList.add(this.NAMESPACE+"_highlight",this.NAMESPACE+"_border"),this.$wrapper.append(this.$border_box),this.$padding_box=document.createElement("div"),this.$padding_box.classList.add(this.NAMESPACE+"_highlight",this.NAMESPACE+"_padding"),this.$wrapper.append(this.$padding_box),this.$content_box=document.createElement("div"),this.$content_box.classList.add(this.NAMESPACE+"_highlight",this.NAMESPACE+"_content"),this.$wrapper.append(this.$content_box),this.$header=document.createElement("div"),this.$header.classList.add(this.NAMESPACE+"_textbox",this.NAMESPACE+"_header");var t="ocr_image_selector"===this.locate?"<b>Image</b>":"<b>Input</b>";this.$header.innerHTML=`
                <div>
                    <div>Click on the CAPTCHA ${t} element to generate a CSS selector.</div>
                    <div>Press <b>ESC</b> to cancel.</div>
                </div>
                <div>
                    <b>NopeCHA</b>
                </div>
            `,this.$wrapper.append(this.$header),this.$footer=document.createElement("div"),this.$footer.classList.add(this.NAMESPACE+"_textbox",this.NAMESPACE+"_footer"),this.$wrapper.append(this.$footer),this.$mark=document.createElement("div"),this.$mark.classList.add(this.NAMESPACE+"_mark"),this.$wrapper.append(this.$mark)}clip(t){var e={top:Math.max(0,t.top),left:Math.max(0,t.left),width:t.width+t.left>window.innerWidth?window.innerWidth-t.left:t.width,height:t.height+t.top>window.innerHeight?window.innerHeight-t.top:t.height};return t.top<0&&(e.height+=t.top),t.left<0&&(e.width+=t.left),e.width<0&&(e.width=0),e.height<0&&(e.height=0),e}computed_style(t,e){let n=window.getComputedStyle(t).getPropertyValue(e);for(const i in n=n.match(/[\-]?[\d\.]+px/g))n[i]=parseFloat(n[i].replace("px",""));return 1===n.length&&n.push(n[0],n[0],n[0]),2===n.length&&n.push(n[0],n[1]),3===n.length&&n.push(n[1]),n}add_dim(t,e){for(const n of e)t.top-=n[0],t.left-=n[3],t.width+=n[1]+n[3],t.height+=n[0]+n[2];return t}sub_dim(t,e){for(const n of e)t.top+=n[0],t.left+=n[3],t.width-=n[1]+n[3],t.height-=n[0]+n[2];return t}set_dim(t,e){e=this.clip(e);t.style.top=e.top+"px",t.style.left=e.left+"px",t.style.width=e.width+"px",t.style.height=e.height+"px"}get_center(t){t=t.getBoundingClientRect();return{x:t.left+t.width/2,y:t.top+t.height/2}}get_css(){return window.CssSelectorGenerator.getCssSelector(this.$t)}update(l,t=0){const d=this;l&&(d.$t=l),d.$t&&(clearTimeout(d.update_timer),d.update_timer=setTimeout(function(){var t=d.$t.getBoundingClientRect(),e=d.computed_style(d.$t,"margin"),n=d.computed_style(d.$t,"border-width"),i=d.computed_style(d.$t,"padding"),t={top:t.top,left:t.left,width:t.width,height:t.height},r=JSON.parse(JSON.stringify(t)),o=JSON.parse(JSON.stringify(t)),s=JSON.parse(JSON.stringify(t)),a=JSON.parse(JSON.stringify(t)),e=(d.add_dim(r,[e]),d.sub_dim(s,[n]),d.sub_dim(a,[n,i]),d.set_dim(d.$margin_box,r),d.set_dim(d.$border_box,o),d.set_dim(d.$padding_box,s),d.set_dim(d.$content_box,a),d.get_css(d.$t)),n=`[${t.width.toFixed(0)}, ${t.height.toFixed(0)}]`,i=(d.$footer.innerHTML=`
                    <div>${e}</div>
                    <div><b>${n}</b></div>
                `,d.get_center(l));d.$mark.style.top=parseInt(i.y-d.MARK_RADIUS)+"px",d.$mark.style.left=parseInt(i.x-d.MARK_RADIUS)+"px"},t))}terminate(){clearTimeout(this.update_timer),this.$style.remove(),this.$wrapper.remove()}}let r=null,n=null;function o(t){t=t.target,t=r.get_css(t);BG.exec("set_settings",{id:r.locate,value:t}),d()}function s(t){t=t.target;t!==n&&(n=t,r.update(t))}function a(t){r.update()}function l(t){t=t||window.event;let e=!1;(e="key"in t?"Escape"===t.key||"Esc"===t.key:27===t.keyCode)&&d()}function d(){document.body.removeEventListener("click",o),document.body.removeEventListener("mousemove",s),document.body.removeEventListener("mousewheel",a),document.body.removeEventListener("keydown",l),r.terminate(),r=null,n=null}chrome.runtime.onMessage.addListener((t,e,n)=>{t.locate&&(t=t.locate,r=new i(t),document.body.addEventListener("click",o),document.body.addEventListener("mousemove",s),document.body.addEventListener("mousewheel",a),document.body.addEventListener("keydown",l))})})();
