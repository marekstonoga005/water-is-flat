(async()=>{setInterval(()=>{document.querySelector("#not_a_bot")?.click()},500)})();
